/*
 *
 * /03-colors/01-change-bcg-one/script.js - 3.1: couleur de fond (1)
 *


 */

// NOTE: don't focus on the existing code structure for now.
// You will have time to focus on it later.

(function() {

    // your code here

})();
