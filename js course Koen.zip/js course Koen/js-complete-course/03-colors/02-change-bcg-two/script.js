/* 
 *
 * /03-colors/02-change-bcg-two/script.js - 3.2: couleur de fond (2)
 *


 */

// NOTE: don't focus on the existing code structure for now.
// You will have time to focus on it later.

(function() {

    // your code here

})();
