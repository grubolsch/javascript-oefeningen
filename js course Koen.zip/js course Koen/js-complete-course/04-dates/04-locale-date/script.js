/* 
 *
 * /04-dates/04-locale-date/script.js - 4.4: date textuelle
 *


 */

// NOTE: don't focus on the existing code structure for now.
// You will have time to focus on it later.

(function() {

    // to change the content of a tag: document.getElementById("element-id").innerHTML = "new-value"

    // your code here

})();
