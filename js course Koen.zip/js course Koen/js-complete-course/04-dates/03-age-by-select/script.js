/*
 *
 * /04-dates/03-age-by-select/script.js - 4.3: calculateur d'âge
 *


 */

// NOTE: don't focus on the existing code structure for now.
// You will have time to focus on it later.

(function() {

    // your code here

})();
