/* 
 *
 * /07-misc/07-storage-clicker/script.js - 7.7: jeu : clicker persistant
 *


 */

// NOTE: don't focus on the existing code structure for now.
// You will have time to focus on it later.

(function() {

    // your code here

})();
