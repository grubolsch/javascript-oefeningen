/*
 *
 * /07-misc/02-typewriter-effect/script.js - 7.2: effet machine à écrire
 *


 */

// NOTE: don't focus on the existing code structure for now.
// You will have time to focus on it later.

(function() {

    // your code here

})();
