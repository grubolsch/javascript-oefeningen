# The fields: JavaScript

Welcome to the JavaScript folder.

## Structure

The file consists of 48 exercises, divided into 9 series.  
Don't be afraid of the number: most of these exercises are very short and focus on a particular aspect.  
The exercises follow one another in a logical _relatively_ way, but don't let one exercise stop you: go to the next, come back to it later.

Each exercise must be done.  
NOTE: **Note: ** The exercises in series 7 are a little more complex, worth a try: they are good syntheses of the progress made.

## Resources

To get the most out of these exercises, some useful resources:

- [Silent Teacher](http://silentteacher.toxicode.fr/) - learn and have fun
- [Solo Learn - Javascript](https://www.sololearn.com/Course/JavaScript/) :uk:
- [Sabe - Javascript](https://sabe.io/classes/javascript) :uk:
- [Mozilla Javascript Guide](https://developer.mozilla.org/fr/docs/Web/JavaScript/Guide/Apropos) :uk: :fr:
- [jsfiddle](https://jsfiddle.net/) - to test your js codes
- [learn x in y minutes](https://learnxinyminutes.com/docs/javascript/)
- [learn js](http://www.learn-js.org/)
- [10 js array methods](https://dev.to/frugencefidel/10-javascript-array-methods-you-should-know-4lk3)

* * *

Good work!

![](https://media.giphy.com/media/xT9DPPqwOCoxi3ASWc/giphy.gif)
