<?php
$a = function($a, $b) {

} use (['b' => 5])