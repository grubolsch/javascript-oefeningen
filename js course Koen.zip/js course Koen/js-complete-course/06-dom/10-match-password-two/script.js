/*
 *
 * /06-dom/10-match-password-two/script.js - 6.10: vérification de mots de passe (2)
 *


 */

// NOTE: don't focus on the existing code structure for now.
// You will have time to focus on it later.

(function() {

    // your code here

})();
