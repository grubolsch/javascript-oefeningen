/* 
 *
 * /06-dom/08-generate-table-two/script.js - 6.8: génération d'un tableau (2)
 *


 */

// NOTE: don't focus on the existing code structure for now.
// You will have time to focus on it later.

(function() {

    // your code here

})();
