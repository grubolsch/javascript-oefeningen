/* 
 *
 * /06-dom/01-select-one/script.js - 6.1: sélection par id
 *


 */

// NOTE: don't focus on the existing code structure for now.
// You will have time to focus on it later.

(function() {

    // your code here

})();
