/* 
 *
 * /06-dom/12-change-event-input-two/script.js - 6.12: événement change (2)
 *


 */

// NOTE: don't focus on the existing code structure for now.
// You will have time to focus on it later.

(function() {

    // your code here

})();
