/* 
 *
 * /06-dom/11-change-event-input-one/script.js - 6.11: événement change (1)
 *


 */

// NOTE: don't focus on the existing code structure for now.
// You will have time to focus on it later.

(function() {

    // your code here

})();
