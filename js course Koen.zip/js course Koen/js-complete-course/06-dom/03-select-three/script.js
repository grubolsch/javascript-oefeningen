/* 
 *
 * /06-dom/03-select-three/script.js - 6.3: sélection multiple par sélecteur css
 *


 */

// NOTE: don't focus on the existing code structure for now.
// You will have time to focus on it later.

(function() {

    // your code here

})();
