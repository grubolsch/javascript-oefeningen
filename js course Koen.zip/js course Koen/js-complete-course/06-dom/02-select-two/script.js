/* 
 *
 * /06-dom/02-select-two/script.js - 6.2: sélection par sélecteur css
 *


 */

// NOTE: don't focus on the existing code structure for now.
// You will have time to focus on it later.

(function() {

    // your code here

})();
