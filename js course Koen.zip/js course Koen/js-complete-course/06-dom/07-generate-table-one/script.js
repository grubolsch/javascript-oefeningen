/* 
 *
 * /06-dom/07-generate-table-one/script.js - 6.7: génération d'un tableau (1)
 *


 */

// NOTE: don't focus on the existing code structure for now.
// You will have time to focus on it later.

(function() {

    // your code here

})();
