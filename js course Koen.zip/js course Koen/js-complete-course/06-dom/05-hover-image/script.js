/* 
 *
 * /06-dom/05-hover-image/script.js - 6.5: survol d'image
 *


 */

// NOTE: don't focus on the existing code structure for now.
// You will have time to focus on it later.

(function() {

    // your code here

})();
