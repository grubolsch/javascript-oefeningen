/*
 *
 * /01-base/04-asv-confirm/script.js - 1.4: ASV avec confirmation
 *


 */

// NOTE: don't focus on the existing code structure for now.
// You will have time to focus on it later.

(function() {

    // your code here

})();
