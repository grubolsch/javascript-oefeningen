/*
 *
 * /01-base/02-var-prompt/script.js - 1.2: var & prompt
 *


 */

// NOTE: don't focus on the existing code structure for now.
// You will have time to focus on it later.

(function() {

    // your code here

})();
