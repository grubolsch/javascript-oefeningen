/* 
 *
 * /02-maths/03-even-square/script.js - 2.3: carrés des pairs
 *


 */

// NOTE: don't focus on the existing code structure for now.
// You will have time to focus on it later.

(function() {

    document.getElementById("run").addEventListener("click", function() {

        // your code here

    });

})();
