/* 
 *
 * /02-maths/06-fizzbuzz/script.js - 2.6: fizzbuzz
 *


 */

// NOTE: don't focus on the existing code structure for now.
// You will have time to focus on it later.

(function() {

    // your code here

})();
