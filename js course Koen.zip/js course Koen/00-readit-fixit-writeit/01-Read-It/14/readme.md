# READ IT
## EX 14
* Look at the reduce() function and research how it works exactly.
* Notice the ', 0' in the reduce function. Inspect the result when you omit this. Explain the difference.
* What are we doing with the object that's passed to 'calculateAvailable'?
