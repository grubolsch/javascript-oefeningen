# READ IT
## EX 02
* Open index.html in your browser. What is the difference between this and the previous example?
* Do you notice a difference between the 2 document.write lines?
* Look at the 'Template literals' documentation

