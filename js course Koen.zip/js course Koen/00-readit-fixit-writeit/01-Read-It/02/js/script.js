const amount = 20;

document.write("<h1>Top " + amount + " Greatest Movies of All Time</h1>");

document.write(`<h2>The first ${amount / 2} movies</h2>`);
