# READ IT
## EX 10
* Look at the documentation of the filter() function and explain how it's used here.