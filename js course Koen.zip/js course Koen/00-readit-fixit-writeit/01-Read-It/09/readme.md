# READ IT
## EX 09
* Notice how the 2 map functions are attached to eachother, this is called 'method chaining'
* What does the parseTitle function do exactly?
* Notice how all the code is in the shape of functions.