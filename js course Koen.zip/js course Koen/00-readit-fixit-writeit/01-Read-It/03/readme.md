# READ IT
## EX 03
* Open script.js and try to predict the result of the script. Explain.
* Open the developer tools in your browser and inspect the 'console' tab.

