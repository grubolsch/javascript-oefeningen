const amount = 10;

for (let i = 0; i < amount; i++) {
  console.log(i);
  document.write(`<p>${i + 1}</p>`);
}
