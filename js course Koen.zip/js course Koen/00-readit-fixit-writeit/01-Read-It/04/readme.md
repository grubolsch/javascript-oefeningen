# READ IT
## EX 04
* Open script.js and read the code. What do you think will happen. Try to explain in your own words.