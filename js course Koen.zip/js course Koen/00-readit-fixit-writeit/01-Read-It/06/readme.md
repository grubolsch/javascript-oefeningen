# READ IT
## EX 06
* Notice the difference with the previous exercise. What changed?
