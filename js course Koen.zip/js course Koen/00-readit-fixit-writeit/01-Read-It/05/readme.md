# READ IT
## Excercise 05
* The for-loop is no longer present. 
  What was it replaced with? How does this work?
* What does the function 'parseTitle' do? 
  What parameter do we pass to this function?
* What does the function 'wrapWithTag' do? 
  Why are the parameters placed between brackets?