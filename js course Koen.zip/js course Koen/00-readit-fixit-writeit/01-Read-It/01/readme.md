# READ IT
## EX 01
* Open index.html in your browser, how is the text displayed on the page?
* Look up the documentation for this function (hint: mdn)
