# READ IT
## EX 12
* Notice the difference with the previous exercise.
* Why is there no 'return' in the parseMovieData function?