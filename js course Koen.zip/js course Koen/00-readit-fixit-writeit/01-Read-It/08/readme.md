# READ IT
## EX 08
* Look at the documentation of the join() function. Explain how it is used here.