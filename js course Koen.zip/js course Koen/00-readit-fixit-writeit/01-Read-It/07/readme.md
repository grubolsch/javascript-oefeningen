# READ IT
## EX 07
* Look at the documentation of the map() function
* What's the difference between this and the previous exercise?

