# READ FIX WRITE 

Train your ES6 JavaScript with the read-fix-write basic exercises.

## Read

Read the readme.md in the provided folders and answer the questions. Make sure you understand what the code does. 
Don't just assume that you get what's going on. Use the documentation to make sure you understand everything.

## Fix

Fix the errors in the provided code. Follow the instructions provided in the readme file.

## Write

Time to write your own code.
