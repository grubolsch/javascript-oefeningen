# FIX IT
## EX 05
In this exercise we want every word in a title to start with a capital letter.
* Look at the error message in the dev tools and fix it.
* Look at the documentation of split().
* Look at the documentation of charAt().
* Look at the documentation of slice().
* Adjust the function to get the desired result