# FIX IT
## EX 06
* We only want to display the shows with a score of 90 or more. You can only make adjustments after line 65.
* Display the score next to the title. Use the following formatting: `colony (100%)`