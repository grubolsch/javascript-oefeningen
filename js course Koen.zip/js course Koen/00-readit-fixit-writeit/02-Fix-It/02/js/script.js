document.write("<h1>The amount most popular tv shows</h1>");
const amount = 10;
