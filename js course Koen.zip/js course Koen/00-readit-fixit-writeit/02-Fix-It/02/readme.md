# FIX IT
## EX 02
* There is nothing displayed on the screen, try to fix this.
* Why isn't 'The 10 most popular tv show' displayed on the screen? Fix it!