# Fix It

Fix the errors in the JavaScript code.
Make us of the documentation on [mdn](https://developer.mozilla.org/bm/). 
Your console is your friend, make use of console.log().

* [01](./01/)
* [02](./02/)
* [03](./03/)
* [04](./04/)
* [05](./05/)
* [06](./06/)
* [07](./07/)