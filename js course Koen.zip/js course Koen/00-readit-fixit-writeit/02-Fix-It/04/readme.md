# FIX IT
## EX 04
* Why are we not seeing any tv shows? Look at the error message in the dev tools and solve it.
* There is still something else going wrong. Fix this as well. 