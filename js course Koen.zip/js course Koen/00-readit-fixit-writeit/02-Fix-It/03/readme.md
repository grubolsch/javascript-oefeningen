# FIX IT
## EX 03
* Why are we not seeing any tv shows? Look at the error message in the dev tools and solve it.
* Try to display the list on the screen in reversed order. (without adjusting the original array)
