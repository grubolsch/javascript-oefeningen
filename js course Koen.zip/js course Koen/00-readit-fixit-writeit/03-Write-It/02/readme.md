# WRITE IT
## EX 02
* Continue with the list form the previous exercise
* Transform the text to lowercase
* Display the list in reversed order