# WRITE IT
## Oefening 05
* Toon alle mogelijke tarieven. Telkens het basis-tarief en dan telkens in combinatie met één supplement.
* Geef de correct prijs weer.
