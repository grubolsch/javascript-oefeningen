# WRITE IT
## EX 03
* Show a list of the last 10 Oscar winners for best actor.
* Sort the list by the age of the winner (oldest first)
* What's the combined age of all Oscar winners. Log this to the console.z
