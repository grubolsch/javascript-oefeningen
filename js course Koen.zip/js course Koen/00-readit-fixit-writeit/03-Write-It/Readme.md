# Fix It

Schrijf zelf je Javascript code.
Maak gebruik van [mdn](https://developer.mozilla.org/bm/) om zaken op te zoeken.

* [01](./01/)
* [02](./02/)
* [03](./03/)
* [04](./04/)
* [05](./05/)