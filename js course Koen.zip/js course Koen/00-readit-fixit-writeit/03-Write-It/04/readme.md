# WRITE IT
## EX 04
* Display the list of actors, only their last name, sorted alfabetically.