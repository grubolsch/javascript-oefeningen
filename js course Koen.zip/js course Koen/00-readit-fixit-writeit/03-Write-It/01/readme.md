# WRITE IT
## EX 01
* Make an array with all movies currently playing in Studio Skoop http://www.studioskoop.be/overzicht_films
* Display the movies in an ul list.